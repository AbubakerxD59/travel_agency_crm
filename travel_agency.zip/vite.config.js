import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
    plugins: [
        laravel({
            input: [
                'resources/css/app.css',
                'resources/js/app.js',
                'resources/js/agents.js',
                'resources/js/companies.js',
                'resources/js/admin-leads-filters.js',
                'resources/js/agent-notifications-poller.js',
                'resources/js/admin-notifications-poller.js',
                'resources/js/dashboard.js',
                'resources/js/admin-dashboard-folder-calendar.js',
            ],
            refresh: true,
        }),
        tailwindcss(),
    ],
    server: {
        watch: {
            ignored: ['**/storage/framework/views/**'],
        },
    },
});
