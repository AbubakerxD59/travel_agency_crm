@php
    $route = request()->route()?->getName();
@endphp

<aside id="admin-sidebar" class="concierge-fixed-sidebar" aria-label="Main navigation">
    <div class="mb-10 flex items-start justify-between gap-2 px-2">
        <div class="min-w-0">
            <p class="text-lg font-bold tracking-tight text-concierge-navy">NAZIRSONS</p>
        </div>
        <button type="button"
            class="admin-sidebar-close -mr-1 -mt-1 flex shrink-0 cursor-pointer items-center justify-center rounded-lg border border-slate-200/80 bg-white/90 p-2 text-concierge-navy shadow-sm transition hover:bg-white hover:text-concierge-navy-deep lg:hidden"
            aria-label="Close menu">
            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                stroke="currentColor" stroke-width="1.5" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>
    </div>

    <nav class="flex flex-1 flex-col gap-1">
        @can('dashboard.access')
            <a href="{{ route('admin.dashboard') }}"
                class="concierge-sidebar-link {{ $route === 'admin.dashboard' ? 'concierge-sidebar-link--active' : '' }}">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75A2.25 2.25 0 0115.75 13.5H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25zM13.5 6A2.25 2.25 0 0115.75 3.75H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25A2.25 2.25 0 0113.5 8.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25A2.25 2.25 0 0110.5 18v2.25A2.25 2.25 0 018 20.25H6a2.25 2.25 0 01-2.25-2.25V15.75z" />
                </svg>
                Dashboard
            </a>
            <a href="{{ route('admin.calendar.index') }}"
                class="concierge-sidebar-link {{ str_starts_with((string) $route, 'admin.calendar.') ? 'concierge-sidebar-link--active' : '' }}">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                Calendar
            </a>
        @endcan

        @can('agents.create')
            <a href="{{ route('admin.agents.index') }}"
                class="concierge-sidebar-link {{ $route === 'admin.agents.index' ? 'concierge-sidebar-link--active' : '' }}">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M18 7.5v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zM3 19.235v-.11a6.375 6.375 0 0112.75 0v.109A12.318 12.318 0 019.374 21c-2.331 0-4.512-.645-6.374-1.766z" />
                </svg>
                Add Agents
            </a>
        @endcan

        @can('leads.access')
            <a href="{{ route('admin.leads.index') }}"
                class="concierge-sidebar-link {{ str_starts_with((string) $route, 'admin.leads.') ? 'concierge-sidebar-link--active' : '' }}">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" />
                </svg>
                Leads
            </a>
            <div class="flex flex-col gap-0.5">
                <a href="{{ route('admin.folders.index') }}"
                    class="concierge-sidebar-link {{ str_starts_with((string) $route, 'admin.folders.') && (string) $route !== 'admin.folders.upcoming' ? 'concierge-sidebar-link--active' : '' }}">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M3.75 5.25A2.25 2.25 0 016 3h3.879a2.25 2.25 0 011.591.659l1.121 1.121A2.25 2.25 0 0014.182 5.5H18A2.25 2.25 0 0120.25 7.75v10.5A2.25 2.25 0 0118 20.5H6a2.25 2.25 0 01-2.25-2.25V5.25z" />
                    </svg>
                    Folders
                </a>
                <a href="{{ route('admin.folders.upcoming') }}"
                    class="concierge-sidebar-link pl-11 text-[13px] leading-snug {{ $route === 'admin.folders.upcoming' ? 'concierge-sidebar-link--active' : '' }}">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M3.75 5.25A2.25 2.25 0 016 3h3.879a2.25 2.25 0 011.591.659l1.121 1.121A2.25 2.25 0 0014.182 5.5H18A2.25 2.25 0 0120.25 7.75v10.5A2.25 2.25 0 0118 20.5H6a2.25 2.25 0 01-2.25-2.25V5.25z" />
                    </svg>
                    Upcoming Folders
                </a>
                <a href="{{ route('admin.folder-payments.index') }}"
                    class="concierge-sidebar-link pl-11 text-[13px] leading-snug {{ str_starts_with((string) $route, 'admin.folder-payments.') ? 'concierge-sidebar-link--active' : '' }}">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 18.75v-.75a.75.75 0 00-.75-.75H3.75a.75.75 0 00-.75.75v.75m19.5 0c0 .621-.504 1.125-1.125 1.125H4.125A1.125 1.125 0 013 20.25v-9.75c0-.621.504-1.125 1.125-1.125h15.75c.621 0 1.125.504 1.125 1.125v9.75z" />
                    </svg>
                    Payments
                </a>
            </div>
        @endcan

        @can('companies.create')
            <a href="{{ route('admin.companies.index') }}"
                class="concierge-sidebar-link {{ str_starts_with((string) $route, 'admin.companies.') ? 'concierge-sidebar-link--active' : '' }}">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75M6.75 21v-3.375c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21M3 3h12m-.75 4.5H21m-3.75 3.75h.008v.008H15.75v-.008zm0 3h.008v.008H15.75V18zm0 3h.008v.008H15.75v-.008z" />
                </svg>
                Companies
            </a>
        @endcan
    </nav>

    @role('super-admin')
        <a href="{{ route('admin.leads.index', ['openAssignLead' => 1]) }}"
            class="mt-4 flex items-center justify-center gap-2 rounded-xl bg-concierge-navy px-4 py-3 text-sm font-semibold text-white shadow-md shadow-concierge-navy/25 transition hover:bg-concierge-navy-deep">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"
                stroke-width="2" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            Assign Lead
        </a>
    @endrole
</aside>
